#!/bin/bash
echo Hello from real script
