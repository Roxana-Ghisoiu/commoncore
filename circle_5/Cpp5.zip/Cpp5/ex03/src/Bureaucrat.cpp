/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rghisoiu <rghisoiu@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/23 14:46:46 by rghisoiu          #+#    #+#             */
/*   Updated: 2025/11/03 19:29:22 by rghisoiu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/AForm.hpp"
#include "../inc/Bureaucrat.hpp"


Bureaucrat::Bureaucrat(const std::string &name, int grade)
: _name(name), _grade(grade) {
if (_grade < 1) throw GradeTooHighException();
if (_grade > 150) throw GradeTooLowException();
}


Bureaucrat::Bureaucrat(const Bureaucrat &other)
: _name(other._name), _grade(other._grade) {}


Bureaucrat::~Bureaucrat() {}


Bureaucrat &Bureaucrat::operator=(const Bureaucrat &other) {
if (this != &other) {
_grade = other._grade; // _name is const
}
return *this;
}


const std::string &Bureaucrat::getName() const { return _name; }
int Bureaucrat::getGrade() const { return _grade; }


void Bureaucrat::incrementGrade() {
if (_grade - 1 < 1) throw GradeTooHighException();
--_grade;
}


void Bureaucrat::decrementGrade() {
if (_grade + 1 > 150) throw GradeTooLowException();
++_grade;
}


void Bureaucrat::signForm(AForm &form) const {
try {
form.beSigned(*this);
std::cout << _name << " signed " << form.getName() << std::endl;
} catch (std::exception &e) {
std::cout << _name << " couldn’t sign " << form.getName()
<< " because " << e.what() << std::endl;
}
}


void Bureaucrat::executeForm(AForm const &form) const {
try {
form.execute(*this);
std::cout << _name << " executed " << form.getName() << std::endl;
} catch (std::exception &e) {
std::cout << _name << " couldn’t execute " << form.getName()
<< " because " << e.what() << std::endl;
}
}


const char *Bureaucrat::GradeTooHighException::what() const throw() { return "grade too high"; }
const char *Bureaucrat::GradeTooLowException::what() const throw() { return "grade too low"; }


std::ostream &operator<<(std::ostream &os, const Bureaucrat &b) {
os << b.getName() << ", bureaucrat grade " << b.getGrade();
return os;
}